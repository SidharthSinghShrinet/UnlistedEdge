import React from "react";
import { SelectDemo } from "./SelectDemo";
function SearchBar() {
  return (
    <form className="w-full flex justify-center items-center py-3 lg:py-6 gap-2 lg:gap-2 bg-gray-200">
      <input
        type="search"
        name="search"
        placeholder="Search Companies..."
        id="search"
        className="w-1/2 h-[38px] rounded-4xl text-md text-gray-500 bg-white  shadow-2xl tracking-wider font-semibold px-3 border-[0.5px] border-gray-300 outline-0"
      />
      <SelectDemo/>
    </form>
  );
}

export default SearchBar;
