// CompanyDetailsPage.jsx
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Papa from "papaparse";
import { useParams } from "react-router-dom";
import {
  setRevenueData,
  setProfitLossData,
  setNetWorth,
  setSelectedCompany,
} from "@/redux/companySlice";
import TabOption from "@/components/TabOption";

function slugify(name) {
  return name
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[().]/g, "")
    .replace(/--+/g, "-");
}

export default function CompanyDetailsPage() {
  const { slug } = useParams();
  const dispatch = useDispatch();
  const allCompanies = useSelector((state) => state.company.allCompanies);

  // Find selected company
  const company = allCompanies.find((c) => slugify(c.Company) === slug);

  // Store selected company in Redux
  useEffect(() => {
    if (company) dispatch(setSelectedCompany(company));
  }, [company]);

  // Load CSV → Revenue, Profit, Net Worth
  useEffect(() => {
    if (!company) return;

    // 1️⃣ PROFIT–LOSS CSV
    Papa.parse("/data/profit_loss_long_format.csv", {
      download: true,
      header: true,
      complete: (result) => {
        const rows = result.data.filter(
          (r) =>
            r.Company &&
            r.Company.trim().toLowerCase() ===
              company.Company.trim().toLowerCase()
        );

        const revenueRow = rows.find((r) => r.Line_Item === "Total_Income");
        const profitRow = rows.find((r) => r.Line_Item === "Net_Profit");

        const yearKeys = Object.keys(revenueRow).filter((key) =>
          key.startsWith("FY")
        );

        const revenueData = yearKeys
          .filter((year) => revenueRow[year] !== "")
          .map((year) => ({ year, value: Number(revenueRow[year]) }));

        const profitData = yearKeys
          .filter((year) => profitRow[year] !== "")
          .map((year) => ({ year, value: Number(profitRow[year]) }));

        dispatch(setRevenueData(revenueData));
        dispatch(setProfitLossData(profitData));
      },
    });

    // 2️⃣ NET WORTH (BALANCE SHEET)
    Papa.parse("/data/balance_sheet_company_year.csv", {
      download: true,
      header: true,
      complete: (result) => {
        const rows = result.data.filter(
          (r) =>
            r.Company &&
            r.Company.trim().toLowerCase() ===
              company.Company.trim().toLowerCase()
        );

        const netWorthData = rows
          .filter((r) => r.Total_Equity_Calculated !== "")
          .map((r) => ({
            year: r.Fiscal_Year,
            value: Number(r.Total_Equity_Calculated),
          }));

        dispatch(setNetWorth(netWorthData));
      },
    });
  }, [company]);

  if (!company) return <h1 className="text-center mt-10">Company Not Found</h1>;

  return (
    <div className="max-w-6xl mx-auto p-5">
      <TabOption />
    </div>
  );
}
