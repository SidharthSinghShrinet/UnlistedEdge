// TabOption.jsx
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "@/components/ui/tabs";
import { useSelector } from "react-redux";
import {
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from "recharts";

export default function TabOption() {
  const company = useSelector((state) => state.company.selectedCompany);
  const revenueData = useSelector((state) => state.company.revenueData);
  const profitLossData = useSelector((state) => state.company.profitLossData);
  const netWorth = useSelector((state) => state.company.netWorth);

  if (!company) return null;

  return (
    <Tabs defaultValue="overview" className="w-full mt-6">
      <TabsList className="grid grid-cols-4 w-full">
        <TabsTrigger value="overview">Overview</TabsTrigger>
        <TabsTrigger value="financials">Financials</TabsTrigger>
        <TabsTrigger value="ratios">Ratios</TabsTrigger>
        <TabsTrigger value="shareholders">Shareholders</TabsTrigger>
      </TabsList>

      {/* OVERVIEW */}
      <TabsContent value="overview">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 my-6">
          <Card label="LTP" value={`₹${company.LTP}`} />
          <Card label="Market Cap" value={`₹${company.Market_Cap_Cr} Cr`} />
          <Card label="Face Value" value={`₹${company.Face_Value}`} />
          <Card label="EPS" value={company.EPS} />
        </div>

        <div className="bg-white shadow p-5 rounded-xl my-6">
          <h2 className="text-xl font-semibold mb-2">About</h2>
          <p>{company.Description || "No description available."}</p>
        </div>
      </TabsContent>

      {/* FINANCIALS */}
      <TabsContent value="financials">
        <FinancialChart title="Revenue Growth" data={revenueData} color="#2563eb" />
        <FinancialChart title="Profit Trends" data={profitLossData} color="#16a34a" />
        <FinancialChart title="Net Worth (Equity)" data={netWorth} color="#9333ea" />
      </TabsContent>

      {/* RATIOS */}
      <TabsContent value="ratios">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 my-6">
          <Card label="PE Ratio" value={company.PE_Ratio} />
          <Card label="PB Ratio" value={company.PB_Ratio} />
          <Card label="PS Ratio" value={company.PS_Ratio} />
        </div>
      </TabsContent>

      <TabsContent value="shareholders">
        <p className="text-gray-500 mt-4">Shareholder data coming soon…</p>
      </TabsContent>
    </Tabs>
  );
}

/* Small reusable UI components */
function Card({ label, value }) {
  return (
    <div className="p-4 shadow bg-white rounded-xl">
      <p className="text-sm text-gray-500">{label}</p>
      <p className="text-xl font-bold">{value}</p>
    </div>
  );
}

function FinancialChart({ title, data, color }) {
  return (
    <div className="bg-white shadow p-5 rounded-xl mb-8">
      <h2 className="text-xl font-semibold mb-4">{title}</h2>
      <LineChart width={600} height={300} data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="year" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="value" stroke={color} strokeWidth={3} />
      </LineChart>
    </div>
  );
}
